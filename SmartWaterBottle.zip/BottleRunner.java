public class BottleRunner 
{
    public static void main(String[] args) 
    {
        // Create a water bottle object and use the instance
        // methods and a print statement to match the desired
        // output:
        WaterBottle jon = new WaterBottle(1.0, 0.6);
        jon.drink(0.4);
        jon.drink(0.4);
        jon.drink(0.3);
        jon.refill(0.6);
        System.out.println(jon);
        
        
        
        
        
        
        
    }
}